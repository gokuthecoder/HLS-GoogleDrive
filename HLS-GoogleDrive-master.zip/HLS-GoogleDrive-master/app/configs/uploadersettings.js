module.exports = {
    "scopes": ['https://www.googleapis.com/auth/drive']
};