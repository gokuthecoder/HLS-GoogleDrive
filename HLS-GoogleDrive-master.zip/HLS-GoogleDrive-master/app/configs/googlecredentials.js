module.exports = {
    "service_accounts": "./app/credentials/service_accounts"
};