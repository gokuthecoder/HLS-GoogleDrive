import { AccountManager } from "./accounts.js";
import fs from "fs";

var accountManager = new AccountManager();
module.exports = accountManager;