

module.exports = {
    API_SERVER:  process.env.API_SERVER || "http://127.0.0.1:5001",
}